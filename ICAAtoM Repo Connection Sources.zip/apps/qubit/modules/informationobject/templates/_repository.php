<div class="section">

  <h2><?php echo __('Repository') ?></h2>

  <div class="content">
    <ul class="clearfix">
 
      <li id="export"><?php echo link_to(__('Export to repository'), array($resource, 'module' => 'sfEadPlugin', 'sf_format' => 'export')) ?></li>
      <li id="delete"><?php echo link_to(__('Delete from repository'), array($resource, 'module' => 'sfEadPlugin', 'sf_format' => 'delete')) ?></li>
    </ul>
  </div>

</div>

<style>
	table.errorDetails td {vertical-align: top;}
	table.errorDetails td:first-child {width: 10%;}
</style>

<script>
	jQuery(document).ready(function() {
		var url_export = jQuery("li#export a").attr("href");
		jQuery("li#export a").click(function(event) {
			jQuery('#content').prepend("<div id='repository' class='actions' style='display:none;margin-bottom:10px;padding:5px;'><div id='sending_ead'><h3>Sending ead to repository... <img id='repository_wait' src='http://ica-atom.atcha.nl/images/loading.gif' /></h3></div></div>");
			jQuery('#repository').show("slow");
			event.preventDefault();
			jQuery.get(url_export, function(data) {
				jQuery('#sending_ead').remove();

				if (1 == data.status) {
					jQuery('#repository').append("<div id='webserviceresponse' class='ok'><h3>EAD successfully uploaded</div>");
				} else {
					jQuery('#repository').append("<div id='webserviceresponse' class='" + data.status + "'><h3>" + data.status.toUpperCase() + "</h3></div>");
					if ("error" == data.status) {
						for (var i=0; i < data.errors.length; i++) {
							jQuery("#webserviceresponse").append("<div='errorDetails'><h4>Error " + (i+1) + "</h4>" + data.errors[i].description + "</div>");
						}
					}
					if ("warning" == data.status) {
						jQuery("#webserviceresponse").append("<div='errorDetails'>" + data.description + "</div>");
					}
				}
			}, "json");
		});
		var url_delete = jQuery("li#delete a").attr("href");
		jQuery("li#delete a").click(function(event) {
			jQuery('#content').prepend("<div id='repository' class='actions' style='display:none;margin-bottom:10px;padding:5px;'><div id='deleting_ead'><h3>Deleting ead from repository... <img id='repository_wait' src='http://ica-atom.atcha.nl/images/loading.gif' /></h3></div></div>");
			jQuery('#repository').show("slow");
			event.preventDefault();
			jQuery.get(url_delete, function(data) {
				jQuery('#deleting_ead').remove();
				if (data.success) {
					jQuery('#repository').append("<div id='webserviceresponse' class='ok'><h3>EAD successfully deleted</div>");
				} else {
					jQuery('#repository').append("<div id='webserviceresponse' class='" + data.status + "'><h3>" + data.status.toUpperCase() + "</h3></div>");
					for (var i=0; i < data.errors.length; i++) {
						jQuery("#webserviceresponse").append("<div='errorDetails'>" + data.errors[i].description + "</div>");
					}
				}
			}, "json");
		});
			
	});

</script>