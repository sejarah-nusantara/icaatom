*****************************************************************************************
Date: 2012-12-07
Author: Hans Versluis (versluis.hans@gmail.com)
*****************************************************************************************

*****************************************************************************************
New files and changed files for the Repository extension of ICA-AtoM
*****************************************************************************************


*****************************************************************************************
Webservice files:
*****************************************************************************************

/plugins/sfEadPlugin/modules/sfEadPlugin/templates/indexSuccess.export.php => sends a EAD file to the repository and prints the status in JSON-format
/plugins/sfEadPlugin/modules/sfEadPlugin/templates/indexSuccess.delete.php => sends a delete request to the repository and prints the status in JSON-format

/plugins/sfEadPlugin/modules/sfEadPlugin/lib/sfEadPlugin.class.php
The last line in method renderEadId() should be changed into:

    return "<eadid$countryCode$mainAgencyCode url=\"$url\" encodinganalog=\"Identifier\">{$this->resource->getDescriptionIdentifier(array('cultureFallback' => true))}</eadid>";

(Notice that only that text-part of this tag has been changed)

/plugins/sfEadPlugin/modules/sfEadPlugin/templates/indexSuccess.xml.php
Change the <langusage>-tag in into
    <langusage>
      <?php foreach ($resource->languageOfDescription as $code): ?>
      <language langcode="<?php echo ($iso6392 = $iso639convertor->getID3($code)) ? strtolower($iso6392) : $code ?>" encodinganalog="Language"><?php echo format_language($code) ?></language>
      <?php endforeach; ?>
    </langusage>


	
*****************************************************************************************
Layout files:
*****************************************************************************************

New layout file:
/apps/qubit/modules/informationobject/_repository.php => display the Export and Delete links. Javascipt to communicate with the webservice files is also included.

File to be changed:
/apps/qubit/modules/informationobject/_contextMenu.php

1 line has to be inserted to the original version of this file:

	[...]
	<?php echo get_partial('informationobject/format', array('resource' => $resource)) ?>

	/* INSERT THIS LINE */
	<?php echo get_partial('informationobject/repository', array('resource' => $resource)) ?>
	/********************/

	<?php if (check_field_visibility('app_element_visibility_physical_storage')): ?>
	  <?php echo get_component('physicalobject', 'contextMenu', array('resource' => $resource)) ?>
	<?php endif; ?>
