<?php 
/*
 * Author: Hans Versluis (versluis.hans@gmail.com)
 * Date: 2012/11/29
 * 
 */

// set the repository's url
$url = 'http://repository.atcha.nl/ead';
set_time_limit(1800);	// large eads may take quite a while to be generated and sent

// create ead_id. This will be used as a filename and will be used as the key in the repository 
$ead_id = $_SERVER["SERVER_NAME"] . "_" . $ead->resource->id . ".ead.xml";

// CHECK IF EAD ALREADY EXISTS IN REPOSITORY	
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_TIMEOUT, '30');
$content = trim(curl_exec($ch));
curl_close($ch);
$list = json_decode ($content);
foreach($list->results as $existingEad) {
	if ($existingEad->ead_id == $ead_id) {
		// EAD EXISTS -> DELETE
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url . "/$ead_id");
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
		curl_exec($ch);
		break;
	}
}
// POST EAD
ob_start(); //Turn on output buffering

// buffer the xml
require("export.xml.php");	// GET XML

$string = ob_get_clean();	// store xml in $string
@unlink($ead_id);	// just to be sure: delete file which might be there in case of errors in previous uploads
file_put_contents($ead_id, $string);	// create xml-file, to be sent to repository

// send xml to repository
$post = array(
    	"file"=>'@'.$ead_id,
);
ob_start();
//execute post
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
curl_setopt($ch, CURLOPT_TIMEOUT, '1800');
$result = curl_exec($ch);
curl_close($ch); //close connection
$response = ob_get_clean();
@unlink($ead_id);
if (strpos($response, "502.shtml") === false) {
	echo $response;
} else {
	/* a nasty hack: if a 502 error is received, the connection with the repository has been lost 
	 * In most cases the xml will have been uploaded correctly. 
	 * */
	sleep(30);	// wait some timt to let the repository do its work
	$response = file_get_contents('http://'.$url.'/'.$ead_id); // check if the EAD has been parsed
	if (strlen($response) == 0) {
		echo '{"status": "error", "description": "The connection with the repository was lost. Please try again after some minutes or contact your system administrator."}';
	} else {
		echo $response;
	}
}
exit;
?>
