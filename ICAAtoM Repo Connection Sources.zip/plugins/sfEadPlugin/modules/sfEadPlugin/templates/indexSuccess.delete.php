<?php 
/*
 * Author: Hans Versluis (versluis.hans@gmail.com)
 * Date: 2012/12/05
 * 
 */

// set the repository's url
$url = 'http://repository.atcha.nl/ead';

// create ead_id. This will be used as a filename and will be used as the key in the repository 
$ead_id = $_SERVER["SERVER_NAME"] . "_" . $ead->resource->id . ".ead.xml";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url . "/$ead_id");
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
echo curl_exec($ch);
exit;
?>
